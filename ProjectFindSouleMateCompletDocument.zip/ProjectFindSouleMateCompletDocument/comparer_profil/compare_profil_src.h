
/*
PROJET LANGAGE C 
Trouver l'âme soeur
nom: compare_profil_src.h
date: 12/2018
programmé par:  Chuan LI
*/

typedef struct ST_profil{
    char *VS_nom;
    int TS_reponses_question[32];	
}ST_profil;



void FN_lire_fichier(ST_profil *, FILE *, char *);
int FN_compare(int *,int *);



