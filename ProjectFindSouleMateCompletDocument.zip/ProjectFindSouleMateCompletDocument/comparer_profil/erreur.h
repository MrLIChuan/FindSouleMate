
/*
PROJET LANGAGE C 
Trouver l'âme soeur
nom: erreur.h
date: 12/2018
programmé par:  Chuan LI
*/

#include <stdio.h>

void FN_Notice_Erreur(int);