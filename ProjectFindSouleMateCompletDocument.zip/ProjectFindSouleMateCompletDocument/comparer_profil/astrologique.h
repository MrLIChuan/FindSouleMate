
/*
PROJET LANGAGE C 
Trouver l'âme soeur
nom: astrologique.h
date: 12/2018
programmé par:  Chuan LI
*/

int FN_astrologique(int, int);